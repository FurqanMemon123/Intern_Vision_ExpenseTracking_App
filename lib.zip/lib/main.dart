
import 'dart:convert';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // 1. State for theme mode is managed here, in the top-level widget.
  bool isDark = true;

  // 2. A function to toggle the theme.
  void _toggleTheme() {
    setState(() {
      isDark = !isDark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Expense Tracker',
      // Light Theme configuration
      theme: ThemeData(
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.light,
          background: Colors.grey[100]!,
          surface: Colors.white,
        ),
        scaffoldBackgroundColor: Colors.grey[100],
        cardColor: Colors.white,
        useMaterial3: true,
      ),
      // Dark Theme configuration
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.dark,
          background: const Color(0xFF121212),
          surface: const Color(0xFF1E1E1E),
        ),
        scaffoldBackgroundColor: const Color(0xFF121212),
        cardColor: const Color(0xFF1E1E1E),
        useMaterial3: true,
      ),
      // Use the 'isDark' state to control which theme is active.
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      // 3. Pass the current theme state and the toggle function to the home screen.
      home: ExpenseHome(isDark: isDark, toggleTheme: _toggleTheme),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Expense {
  final String title;
  final double amount;
  final String category;
  final DateTime date;

  Expense({
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
    'title': title,
    'amount': amount,
    'category': category,
    'date': date.toIso8601String(),
  };

  factory Expense.fromJson(Map<String, dynamic> json) => Expense(
    title: json['title'],
    amount: json['amount'],
    category: json['category'],
    date: DateTime.parse(json['date']),
  );
}

class ExpenseHome extends StatefulWidget {
  // 4. Receive the state and callback function from MyApp.
  final bool isDark;
  final VoidCallback toggleTheme;

  const ExpenseHome({
    Key? key,
    required this.isDark,
    required this.toggleTheme,
  }) : super(key: key);

  @override
  _ExpenseHomeState createState() => _ExpenseHomeState();
}

class _ExpenseHomeState extends State<ExpenseHome> {
  List<Expense> _expenses = [];

  final _titleCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String _selectedCategory = "General";

  final Map<String, Color> categoryColors = {
    "General": Colors.blue,
    "Food": Colors.green,
    "Transport": Colors.orange,
    "Shopping": Colors.purple,
  };

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _saveExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> jsonList =
        _expenses.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList('expenses', jsonList);
  }

  Future<void> _loadExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String>? jsonList = prefs.getStringList('expenses');
    if (jsonList != null) {
      setState(() {
        _expenses =
            jsonList.map((e) => Expense.fromJson(jsonDecode(e))).toList();
      });
    }
  }

  void _addExpense() {
    if (_titleCtrl.text.isEmpty || _amountCtrl.text.isEmpty) return;

    setState(() {
      _expenses.add(
        Expense(
          title: _titleCtrl.text,
          amount: double.tryParse(_amountCtrl.text) ?? 0,
          category: _selectedCategory,
          date: DateTime.now(),
        ),
      );
      _titleCtrl.clear();
      _amountCtrl.clear();
      _selectedCategory = "General";
    });

    _saveExpenses();
  }

  List<PieChartSectionData> _getChartData() {
    final Map<String, double> categoryTotals = {};
    for (var e in _expenses) {
      categoryTotals[e.category] = (categoryTotals[e.category] ?? 0) + e.amount;
    }

    return categoryTotals.entries.map((entry) {
      return PieChartSectionData(
        value: entry.value,
        title: entry.key,
        color: categoryColors[entry.key] ?? Colors.grey,
        radius: 60,
        titleStyle: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      );
    }).toList();
  }

  void _deleteExpense(int i) {
    setState(() {
      _expenses.removeAt(i);
    });
    _saveExpenses();
  }

  void _editExpense(int i, Expense oldExpense) {
    final _editTitleCtrl = TextEditingController(text: oldExpense.title);
    final _editAmountCtrl = TextEditingController(
      text: oldExpense.amount.toString(),
    );
    String _editCategory = oldExpense.category;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setStateDialog) {
            return AlertDialog(
              title: const Text("Edit Expense"),
content: SingleChildScrollView(
  child: Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.stretch, // 👈 Align fields properly
    children: [
      TextField(
        controller: _editTitleCtrl,
        decoration: const InputDecoration(labelText: "Title"),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: _editAmountCtrl,
        decoration: const InputDecoration(labelText: "Amount"),
        keyboardType: TextInputType.number,
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: _editCategory,
        items: ["General", "Food", "Transport", "Shopping"]
            .map(
              (cat) => DropdownMenuItem(value: cat, child: Text(cat)),
            )
            .toList(),
        onChanged: (val) {
          setStateDialog(() => _editCategory = val!);
        },
        decoration: const InputDecoration(labelText: "Category"),
      ),
    ],
  ),
),

              actions: [
                TextButton(
                  child: const Text("Cancel"),
                  onPressed: () => Navigator.pop(ctx),
                ),
                ElevatedButton(
                  child: const Text("Save"),
                  onPressed: () {
                    setState(() {
                      _expenses[i] = Expense(
                        title: _editTitleCtrl.text,
                        amount: double.tryParse(_editAmountCtrl.text) ?? 0.0,
                        category: _editCategory,
                        date: oldExpense.date,
                      );
                    });
                    _saveExpenses();
                    Navigator.pop(ctx);
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text("Expense Tracker"),
        backgroundColor: Theme.of(context).colorScheme.surface,
        actions: [
          // 5. Use the passed-in function and state to build the button.
          IconButton(
              onPressed: widget.toggleTheme,
              icon: Icon(widget.isDark
                  ? Icons.light_mode_outlined
                  : Icons.dark_mode_outlined))
        ],
      ),
      body: Container(
        color: Theme.of(context).colorScheme.background,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              // Input fields
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _titleCtrl,
                      decoration: const InputDecoration(labelText: "Title"),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _amountCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: "Amount"),
                    ),
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: _selectedCategory,
                    items: ["General", "Food", "Transport", "Shopping"]
                        .map(
                          (cat) =>
                              DropdownMenuItem(value: cat, child: Text(cat)),
                        )
                        .toList(),
                    onChanged: (val) => setState(() => _selectedCategory = val!),
                  ),
                  IconButton(
                    // ✅ FIX: Use theme color instead of hardcoded blue.
                    icon: Icon(Icons.add_circle,
                        color: Theme.of(context).colorScheme.primary),
                    onPressed: _addExpense,
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Pie Chart
              if (_expenses.isNotEmpty) ...[
                SizedBox(
                  height: 200,
                  child: PieChart(
                    PieChartData(
                      sections: _getChartData(),
                      centerSpaceRadius: 30,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 12,
                  children: categoryColors.entries.map((e) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircleAvatar(backgroundColor: e.value, radius: 6),
                        const SizedBox(width: 4),
                        Text(e.key),
                      ],
                    );
                  }).toList(),
                ),
                const Divider(),
              ],

              // Expense List
              Expanded(
                child: _expenses.isEmpty
                    ? const Center(child: Text("No expenses yet."))
                    : ListView.builder(
                        itemCount: _expenses.length,
                        itemBuilder: (ctx, i) {
                          final e = _expenses[i];
                          return Card(
                            color: Theme.of(context).cardColor,
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: ListTile(
                              leading: const Icon(Icons.monetization_on),
                              title: Text(
                                e.title,
                                style: TextStyle(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurface),
                              ),
                              subtitle: Text(
                                "${e.category} • ${DateFormat.yMMMd().format(e.date)}",
                              ),
                              trailing: SizedBox(
                                width: 130,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        "Rs ${e.amount.toStringAsFixed(2)}",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          // ✅ FIX: Use theme color for text.
                                          color: Theme.of(context)
                                              .colorScheme
                                              .onSurface,
                                          height: 0.7,
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          IconButton(
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(
                                                minWidth: 20, minHeight: 20),
                                            icon: Icon(
                                              Icons.edit,
                                              // ✅ FIX: Use theme color for icon.
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .primary,
                                              size: 16,
                                            ),
                                            onPressed: () => _editExpense(i, e),
                                          ),
                                          IconButton(
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(
                                                minWidth: 20, minHeight: 20),
                                            icon: Icon(
                                              Icons.delete,
                                              // ✅ FIX: Use theme error color for icon.
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .error,
                                              size: 16,
                                            ),
                                            onPressed: () => _deleteExpense(i),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}